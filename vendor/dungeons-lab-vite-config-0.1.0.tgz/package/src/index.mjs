import { execFileSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { assertEdition, devToolsEnabled } from "@dungeons-lab/editions/simple";

const DEV_TOOLS_ID = "virtual:dungeons-lab/dev-tools";
const BUILD_IDENTITY_ID = "virtual:dungeons-lab/build-identity";
const RESOLVED_DEV_TOOLS_ID = `\0${DEV_TOOLS_ID}`;
const RESOLVED_BUILD_IDENTITY_ID = `\0${BUILD_IDENTITY_ID}`;
const SIMPLE_OPTIONS = new Set(["devEntry"]);
const CONFIG_OPTIONS = new Set([
  "root", "entry", "editions", "vitePlugins", "define", "aliases", "styles", "output", "extend",
]);

function assertKnownOptions(value, allowed, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError(`${label} must be an object`);
  }
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) throw new TypeError(`${label}: unknown option ${JSON.stringify(key)}`);
  }
}

function configDirectory(root) {
  if (root instanceof URL) return path.dirname(fileURLToPath(root));
  if (typeof root !== "string" || root.length === 0) {
    throw new TypeError("createFoundryModuleConfig: root must be the vite config's import.meta.url");
  }
  if (root.startsWith("file:")) return path.dirname(fileURLToPath(root));
  return path.dirname(path.resolve(root));
}

function readJsonIfPresent(file) {
  if (!existsSync(file)) return null;
  try {
    return JSON.parse(readFileSync(file, "utf8"));
  } catch (error) {
    throw new Error(`Cannot read JSON identity from ${file}: ${error.message}`);
  }
}

function gitValue(cwd, args, fallback) {
  try {
    return execFileSync("git", args, { cwd, encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
  } catch {
    return fallback;
  }
}

function collectBuildIdentity(moduleRoot, env = process.env) {
  const manifest = readJsonIfPresent(path.join(moduleRoot, "module.json"));
  const packageJson = readJsonIfPresent(path.join(moduleRoot, "package.json"));
  const version = manifest?.version ?? packageJson?.version;
  if (typeof version !== "string" || version.length === 0) {
    throw new Error(`Cannot determine build version in ${moduleRoot}; add module.json or package.json`);
  }
  const builtAt = env.DL_BUILT_AT ?? new Date().toISOString();
  if (Number.isNaN(Date.parse(builtAt))) throw new Error(`DL_BUILT_AT is not a valid date: ${builtAt}`);
  const sha = gitValue(moduleRoot, ["rev-parse", "--short=12", "HEAD"], "unknown");
  const status = gitValue(moduleRoot, ["status", "--porcelain", "--untracked-files=normal"], "");
  return Object.freeze({
    ...(typeof manifest?.id === "string" ? { moduleId: manifest.id } : {}),
    version,
    sha,
    dirty: status.length > 0,
    builtAt: new Date(builtAt).toISOString(),
  });
}

function normalize(file) {
  return path.resolve(file).replaceAll("\\", "/");
}

function isInside(file, directory) {
  return file === directory || file.startsWith(`${directory}/`);
}

function editionPlugin({ moduleRoot, devEntry, edition, identity }) {
  const devRoot = normalize(path.join(moduleRoot, "src", "dev"));
  const absoluteDevEntry = normalize(path.resolve(moduleRoot, devEntry));
  if (!isInside(absoluteDevEntry, devRoot)) {
    throw new Error(`simpleEditions devEntry must resolve inside src/dev: ${absoluteDevEntry}`);
  }
  const sentinel = `DL_DEV_SENTINEL_${identity.moduleId ?? "unknown-module"}`;

  return {
    name: "dungeons-lab-simple-editions",
    enforce: "pre",
    async resolveId(source, importer) {
      if (source === DEV_TOOLS_ID) return RESOLVED_DEV_TOOLS_ID;
      if (source === BUILD_IDENTITY_ID) return RESOLVED_BUILD_IDENTITY_ID;
      if (!importer || importer === RESOLVED_DEV_TOOLS_ID) return null;

      const cleanImporter = normalize(importer.split("?", 1)[0]);
      if (isInside(cleanImporter, devRoot)) return null;
      const resolved = await this.resolve(source, importer, { skipSelf: true });
      let candidate = resolved?.id?.split("?", 1)[0];
      if (!candidate && source.startsWith(".")) candidate = path.resolve(path.dirname(importer), source);
      else if (!candidate && path.isAbsolute(source)) candidate = source;
      if (candidate && isInside(normalize(candidate), devRoot)) {
        this.error(`Dungeons LAB dev import fence: ${cleanImporter} may not import ${normalize(candidate)}; import ${DEV_TOOLS_ID} instead`);
      }
      return null;
    },
    load(id) {
      if (id === RESOLVED_DEV_TOOLS_ID) {
        if (!devToolsEnabled(edition)) return "export function registerDevTools() {}\n";
        return [
          `export { registerDevTools } from ${JSON.stringify(absoluteDevEntry)};`,
          `export const DL_DEV_SENTINEL = ${JSON.stringify(sentinel)};`,
          "globalThis.__DL_DEV_SENTINELS__?.add(DL_DEV_SENTINEL);",
          "",
        ].join("\n");
      }
      if (id === RESOLVED_BUILD_IDENTITY_ID) {
        return `export const buildIdentity = Object.freeze(${JSON.stringify(identity)});\nexport default buildIdentity;\n`;
      }
      return null;
    },
  };
}

export function simpleEditions(options = {}) {
  assertKnownOptions(options, SIMPLE_OPTIONS, "simpleEditions");
  const devEntry = options.devEntry ?? "src/dev/index.mjs";
  if (typeof devEntry !== "string" || devEntry.length === 0) throw new TypeError("simpleEditions: devEntry must be a path");
  return Object.freeze({ kind: "dungeons-lab-simple-editions", devEntry });
}

export function createFoundryModuleConfig(options) {
  assertKnownOptions(options, CONFIG_OPTIONS, "createFoundryModuleConfig");
  if (!("root" in options)) throw new TypeError("createFoundryModuleConfig: root is required");
  const moduleRoot = configDirectory(options.root);
  const entry = options.entry ?? "src/module.mjs";
  const vitePlugins = options.vitePlugins ?? [];
  const extraDefine = options.define ?? {};
  const aliases = options.aliases ?? {};
  const styles = { fileName: "styles/module.css", ...(options.styles ?? {}) };
  const output = { dir: "dist", clean: true, chunks: "preserve", ...(options.output ?? {}) };

  assertKnownOptions(styles, new Set(["fileName"]), "styles");
  assertKnownOptions(output, new Set(["dir", "clean", "chunks"]), "output");
  if (output.chunks !== "preserve") throw new TypeError('output.chunks must be "preserve"');
  if (!Array.isArray(vitePlugins)) throw new TypeError("vitePlugins must be an array");
  if (!extraDefine || typeof extraDefine !== "object" || Array.isArray(extraDefine)) throw new TypeError("define must be an object");
  if ("__DL_EDITION__" in extraDefine) throw new Error("__DL_EDITION__ is forbidden; read flags.dlEdition at runtime");
  if ("__DL_DEV_TOOLS__" in extraDefine) throw new Error("__DL_DEV_TOOLS__ is managed by simpleEditions");

  const resolvedAliases = Object.fromEntries(Object.entries(aliases).map(([key, value]) => {
    if (typeof value !== "string") throw new TypeError(`alias ${key} must be a path string`);
    return [key, path.resolve(moduleRoot, value)];
  }));
  let edition = null;
  let identity = null;
  const plugins = [...vitePlugins];
  const define = { ...extraDefine };
  if (options.editions !== undefined) {
    if (options.editions?.kind !== "dungeons-lab-simple-editions") throw new TypeError("editions must be the result of simpleEditions()");
    edition = assertEdition(process.env.DL_EDITION ?? "test");
    identity = collectBuildIdentity(moduleRoot);
    plugins.push(editionPlugin({ moduleRoot, devEntry: options.editions.devEntry, edition, identity }));
    define.__DL_DEV_TOOLS__ = devToolsEnabled(edition);
  }

  let config = {
    root: moduleRoot,
    plugins,
    define,
    resolve: { alias: resolvedAliases },
    build: {
      outDir: output.dir,
      emptyOutDir: output.clean,
      sourcemap: edition === null || edition === "test",
      minify: false,
      cssCodeSplit: false,
      lib: {
        entry: path.resolve(moduleRoot, entry),
        formats: ["es"],
        fileName: () => "module.mjs",
      },
      rollupOptions: {
        output: {
          assetFileNames: (asset) => asset.name?.endsWith(".css") ? styles.fileName : "assets/[name]-[hash][extname]",
        },
      },
    },
  };
  if (options.extend !== undefined) {
    if (typeof options.extend !== "function") throw new TypeError("extend must be a function");
    config = options.extend(Object.freeze({ root: moduleRoot, edition, identity }), config);
    if (!config || typeof config !== "object") throw new TypeError("extend must return a Vite config object");
  }
  return config;
}

export { BUILD_IDENTITY_ID, DEV_TOOLS_ID };
