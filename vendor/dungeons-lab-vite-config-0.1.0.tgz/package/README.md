# @dungeons-lab/vite-config

Constrained Vite 5 configuration for Dungeons LAB Foundry modules. It produces an ES library at
`dist/module.mjs`, keeps hashed split chunks inside `dist`, coalesces CSS to
`dist/styles/module.css`, and intentionally exposes only the documented factory options.

```js
import { createFoundryModuleConfig, simpleEditions } from "@dungeons-lab/vite-config";

export default createFoundryModuleConfig({
  root: import.meta.url,
  editions: simpleEditions({ devEntry: "src/dev/index.mjs" }),
});
```

`DL_EDITION` is `free`, `paid`, or `test`; an unset value deliberately means `test`. Application
code may import `virtual:dungeons-lab/build-identity` (default export and named `buildIdentity`)
and `virtual:dungeons-lab/dev-tools`. The canonical dev-tools export shape is exactly:

```js
export function registerDevTools() {}
```

The test virtual module re-exports that function from `devEntry` and contains the fixed marker
literal `DL_DEV_SENTINEL_<module-id>`. Free and paid builds receive only the no-op and never contain
the marker, including in sourcemaps. Direct imports into `src/dev/**` from outside that directory
are rejected. Runtime edition display must read `flags.dlEdition` from `module.json`; this package
does not define `__DL_EDITION__` or embed the edition in build identity. Embedded build identity is
the frozen `{ moduleId?, version, sha, dirty, builtAt }` shape. Edition builds emit sourcemaps only
for `test`; no-editions migration builds retain the default `sourcemap: true` behavior.

Set `DL_BUILT_AT` to an ISO-compatible timestamp for reproducible build identity output.
