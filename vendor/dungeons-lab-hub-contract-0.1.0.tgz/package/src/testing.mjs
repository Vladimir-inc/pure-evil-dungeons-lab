import { validateModuleManifestV1 } from "./index.mjs";

const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const LEAKAGE_KEYS = ["scope", "default", "onChange", "config"];

export function createHubHarness() {
  const registered = new Map();
  const registrationTokens = new Map();
  const listeners = new Map();
  const settings = new Map();
  const Hooks = {
    on(hook, callback) {
      if (!listeners.has(hook)) listeners.set(hook, new Set());
      listeners.get(hook).add(callback);
      return () => Hooks.off(hook, callback);
    },
    once(hook, callback) {
      const wrapped = (...args) => {
        Hooks.off(hook, wrapped);
        callback(...args);
      };
      return Hooks.on(hook, wrapped);
    },
    off(hook, callback) {
      listeners.get(hook)?.delete(callback);
    },
    callAll(hook, ...args) {
      for (const callback of [...(listeners.get(hook) ?? [])]) callback(...args);
    },
  };
  const api = {
    apiVersion: 1,
    registered,
    get registeredList() { return [...registered.values()]; },
    registerModule(manifest) {
      const token = {};
      registered.set(manifest.id, manifest);
      registrationTokens.set(manifest.id, token);
      return () => {
        if (registrationTokens.get(manifest.id) === token) {
          registrationTokens.delete(manifest.id);
          registered.delete(manifest.id);
        }
      };
    },
  };
  const game = {
    modules: new Map(),
    settings: {
      settings,
      register(moduleId, key, config) {
        settings.set(`${moduleId}.${key}`, config);
      },
    },
  };
  return {
    api,
    registered,
    game,
    Hooks,
    fireReady(readyApi = api) {
      Hooks.callAll("dungeonsLabHub.ready", readyApi);
    },
  };
}

function dictionaryGet(dictionary, key) {
  if (!object(dictionary) || typeof key !== "string") return undefined;
  if (own(dictionary, key)) return dictionary[key];
  return key.split(".").reduce((value, part) => value == null ? undefined : value[part], dictionary);
}

function registryMap(settingsRegistry) {
  if (settingsRegistry instanceof Map) return settingsRegistry;
  if (settingsRegistry?.settings instanceof Map) return settingsRegistry.settings;
  return undefined;
}

function registeredConfig(map, moduleId, key) {
  const entry = map?.get(key) ?? map?.get(`${moduleId}.${key}`);
  if (entry?.config && object(entry.config)) return entry.config;
  return entry;
}

function knownSettingKeys(settingKeys) {
  if (settingKeys == null) return new Set();
  if (typeof settingKeys[Symbol.iterator] === "function" && typeof settingKeys !== "string") return new Set(settingKeys);
  if (object(settingKeys)) return new Set(Object.values(settingKeys));
  return new Set();
}

function sameData(left, right) {
  if (left === right) return true;
  if (!object(left) || !object(right)) return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every((key, index) => key === rightKeys[index] && left[key] === right[key]);
}

export function auditManifest(manifest, { settingsRegistry, i18n = {}, settingKeys } = {}) {
  const errors = [...validateModuleManifestV1(manifest).errors];
  if (!object(manifest) || !Array.isArray(manifest.settings)) return { ok: errors.length === 0, errors };
  const known = knownSettingKeys(settingKeys);
  const registrations = registryMap(settingsRegistry);
  for (const [index, view] of manifest.settings.entries()) {
    if (!object(view)) continue;
    const path = `manifest.settings[${index}]`;
    if (!known.has(view.key)) errors.push(`${path}.key "${view.key}" is not in settingKeys`);
    const config = registeredConfig(registrations, manifest.id, view.key);
    if (config === undefined) errors.push(`${path}.key "${view.key}" is not registered`);
    for (const key of LEAKAGE_KEYS) {
      if (own(view, key) && !errors.some((error) => error.includes(`${path}.${key}`))) {
        errors.push(`${path}.${key} is forbidden presentation leakage`);
      }
    }
    for (const field of ["label", "hint", "group"]) {
      if (!own(view, field)) continue;
      for (const language of ["en", "ru"]) {
        if (dictionaryGet(i18n[language], view[field]) === undefined) {
          errors.push(`${path}.${field} "${view[field]}" is missing from i18n.${language}`);
        }
      }
    }
    if (view.type === "select" && config !== undefined && !sameData(view.choices, config?.choices)) {
      errors.push(`${path}.choices do not match the registered choices`);
    }
  }
  for (const key of known) {
    if (!manifest.settings.some((view) => object(view) && view.key === key)) {
      errors.push(`settingKey "${key}" is not present in manifest.settings`);
    }
  }
  return { ok: errors.length === 0, errors };
}
