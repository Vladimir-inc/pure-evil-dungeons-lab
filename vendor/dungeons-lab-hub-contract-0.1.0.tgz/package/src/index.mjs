export const HUB_API_VERSION = 1;
export const HUB_READY_HOOK = "dungeonsLabHub.ready";

const own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
const object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const nonEmptyString = (value) => typeof value === "string" && value.length > 0;
const LEAKAGE_KEYS = new Set(["scope", "default", "onChange", "config"]);
const META_KEYS = ["group", "keywords", "requiresReload", "visibleWhen"];
const BASE_KEYS = ["key", "type", "label", "hint", ...META_KEYS];
const VIEW_KEYS = {
  boolean: BASE_KEYS,
  number: [...BASE_KEYS, "min", "max", "step"],
  string: BASE_KEYS,
  select: [...BASE_KEYS, "choices"],
  color: BASE_KEYS,
  file: [...BASE_KEYS, "fileType"],
  action: [...BASE_KEYS, "icon", "danger", "run"],
  custom: [...BASE_KEYS, "render"],
};
const MANIFEST_KEYS = new Set(["id", "title", "icon", "settings", "panels", "licensing", "settingsAccess"]);

function exactKeys(value, allowed, path, errors) {
  const allowedSet = allowed instanceof Set ? allowed : new Set(allowed);
  for (const key of Object.keys(value)) {
    if (!allowedSet.has(key)) errors.push(`${path}.${key} is not allowed`);
  }
}

function validateMeta(view, path, errors) {
  if (own(view, "group") && !nonEmptyString(view.group)) errors.push(`${path}.group must be a non-empty string`);
  if (own(view, "keywords") && (!Array.isArray(view.keywords) || view.keywords.some((item) => !nonEmptyString(item)))) {
    errors.push(`${path}.keywords must be an array of non-empty strings`);
  }
  if (own(view, "requiresReload") && typeof view.requiresReload !== "boolean") {
    errors.push(`${path}.requiresReload must be a boolean`);
  }
  if (own(view, "visibleWhen")) {
    if (!object(view.visibleWhen)) {
      errors.push(`${path}.visibleWhen must be an object`);
    } else {
      exactKeys(view.visibleWhen, ["key", "equals"], `${path}.visibleWhen`, errors);
      if (!nonEmptyString(view.visibleWhen.key)) errors.push(`${path}.visibleWhen.key must be a non-empty string`);
    }
  }
}

function validateView(view, path, errors) {
  if (!object(view)) {
    errors.push(`${path} must be an object`);
    return;
  }
  for (const key of LEAKAGE_KEYS) {
    if (own(view, key)) errors.push(`${path}.${key} is forbidden presentation leakage`);
  }
  if (!nonEmptyString(view.key)) errors.push(`${path}.key must be a non-empty string`);
  if (!nonEmptyString(view.type) || !own(VIEW_KEYS, view.type)) {
    errors.push(`${path}.type must be one of ${Object.keys(VIEW_KEYS).join(", ")}`);
    return;
  }
  exactKeys(view, VIEW_KEYS[view.type], path, errors);
  if (view.type === "custom") {
    if (own(view, "label") && !nonEmptyString(view.label)) errors.push(`${path}.label must be a non-empty string when provided`);
  } else if (!nonEmptyString(view.label)) {
    errors.push(`${path}.label must be a non-empty string`);
  }
  if (own(view, "hint") && !nonEmptyString(view.hint)) errors.push(`${path}.hint must be a non-empty string when provided`);
  validateMeta(view, path, errors);

  if (view.type === "number") {
    for (const key of ["min", "max", "step"]) {
      if (own(view, key) && (typeof view[key] !== "number" || !Number.isFinite(view[key]))) {
        errors.push(`${path}.${key} must be a finite number`);
      }
    }
  } else if (view.type === "select") {
    if (!object(view.choices) || Object.values(view.choices).some((choice) => typeof choice !== "string")) {
      errors.push(`${path}.choices must be an object with string values`);
    }
  } else if (view.type === "file" && own(view, "fileType") && !["image", "video", "any"].includes(view.fileType)) {
    errors.push(`${path}.fileType must be image, video, or any`);
  } else if (view.type === "action") {
    if (own(view, "icon") && !nonEmptyString(view.icon)) errors.push(`${path}.icon must be a non-empty string when provided`);
    if (own(view, "danger") && typeof view.danger !== "boolean") errors.push(`${path}.danger must be a boolean`);
    if (typeof view.run !== "function") errors.push(`${path}.run must be a function`);
  } else if (view.type === "custom" && typeof view.render !== "function") {
    errors.push(`${path}.render must be a function`);
  }
}

function validatePanel(panel, path, errors) {
  if (!object(panel)) {
    errors.push(`${path} must be an object`);
    return;
  }
  exactKeys(panel, ["id", "title", "icon", "section", "badge", "render"], path, errors);
  if (!nonEmptyString(panel.id)) errors.push(`${path}.id must be a non-empty string`);
  if (!nonEmptyString(panel.title)) errors.push(`${path}.title must be a non-empty string`);
  if (own(panel, "icon") && !nonEmptyString(panel.icon)) errors.push(`${path}.icon must be a non-empty string when provided`);
  if (own(panel, "section") && !["library", "tools"].includes(panel.section)) errors.push(`${path}.section must be library or tools`);
  if (own(panel, "badge") && typeof panel.badge !== "function") errors.push(`${path}.badge must be a function`);
  if (typeof panel.render !== "function") errors.push(`${path}.render must be a function`);
}

export function isHubApiV1(api) {
  return object(api) && api.apiVersion === HUB_API_VERSION && typeof api.registerModule === "function";
}

export function validateModuleManifestV1(manifest) {
  const errors = [];
  if (!object(manifest)) return { ok: false, errors: ["manifest must be an object"] };
  exactKeys(manifest, MANIFEST_KEYS, "manifest", errors);
  if (!nonEmptyString(manifest.id)) errors.push("manifest.id must be a non-empty string");
  if (!nonEmptyString(manifest.title)) errors.push("manifest.title must be a non-empty string");
  if (own(manifest, "icon") && !nonEmptyString(manifest.icon)) errors.push("manifest.icon must be a non-empty string when provided");
  if (own(manifest, "settings")) {
    if (!Array.isArray(manifest.settings)) errors.push("manifest.settings must be an array");
    else manifest.settings.forEach((view, index) => validateView(view, `manifest.settings[${index}]`, errors));
  }
  if (own(manifest, "panels")) {
    if (!Array.isArray(manifest.panels)) errors.push("manifest.panels must be an array");
    else manifest.panels.forEach((panel, index) => validatePanel(panel, `manifest.panels[${index}]`, errors));
  }
  if (own(manifest, "licensing")) {
    if (!object(manifest.licensing)) errors.push("manifest.licensing must be an object");
    else {
      exactKeys(manifest.licensing, ["isLicensed", "activate"], "manifest.licensing", errors);
      if (typeof manifest.licensing.isLicensed !== "function") errors.push("manifest.licensing.isLicensed must be a function");
      if (typeof manifest.licensing.activate !== "function") errors.push("manifest.licensing.activate must be a function");
    }
  }
  if (own(manifest, "settingsAccess") && typeof manifest.settingsAccess !== "function") {
    errors.push("manifest.settingsAccess must be a function");
  }
  return { ok: errors.length === 0, errors };
}

export function assertModuleManifestV1(manifest) {
  const result = validateModuleManifestV1(manifest);
  if (!result.ok) throw new TypeError(`Invalid Hub ModuleManifestV1:\n${result.errors.map((error) => `- ${error}`).join("\n")}`);
  return manifest;
}

export function registerWithHub(hubId, buildManifest, env = {}) {
  if (!nonEmptyString(hubId)) throw new TypeError("hubId must be a non-empty string");
  if (typeof buildManifest !== "function") throw new TypeError("buildManifest must be a function");
  const game = env.game ?? globalThis.game;
  const Hooks = env.Hooks ?? globalThis.Hooks;
  let liveUnregister;
  let disposed = false;

  const register = (api) => {
    if (disposed || liveUnregister || !isHubApiV1(api)) return;
    const manifest = assertModuleManifestV1(buildManifest());
    const unregister = api.registerModule(manifest);
    liveUnregister = typeof unregister === "function" ? unregister : () => {};
  };

  register(game?.modules?.get?.(hubId)?.api);
  const listener = (api) => register(api);
  const subscription = typeof Hooks?.on === "function" ? Hooks.on(HUB_READY_HOOK, listener) : undefined;

  return {
    unregister() {
      if (disposed) return;
      disposed = true;
      liveUnregister?.();
      liveUnregister = undefined;
      if (typeof subscription === "function") subscription();
      else if (typeof Hooks?.off === "function") Hooks.off(HUB_READY_HOOK, listener);
    },
  };
}
