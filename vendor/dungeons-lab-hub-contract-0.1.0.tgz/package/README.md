# @dungeons-lab/hub-contract

This package is the **single source of truth** for the `HubApiV1` wire contract used across the Dungeons LAB ecosystem. It provides the runtime constants, strict manifest validation, and the canonical dual-handshake helper from the main export, plus dependency-free Foundry fakes and manifest auditing from `@dungeons-lab/hub-contract/testing`.

The Hub re-exports or aligns its TypeScript types against this package. That alignment is performed in a separate Hub-side task.

```js
import { registerWithHub } from "@dungeons-lab/hub-contract";

const registration = registerWithHub("dungeons-lab-hub", () => ({
  id: "my-module",
  title: "MY_MODULE.Title",
  settings: [],
}));

// During teardown:
registration.unregister();
```
