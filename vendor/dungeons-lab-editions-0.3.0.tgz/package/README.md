# @dungeons-lab/editions

Generic catalog/build-resolution engine for the "editions" (free/paid/test tier) pattern used
across Dungeons LAB Foundry VTT modules. Lifted verbatim from StoryFlow's
`scripts/lib/editions-core/*.mjs` (zero product-specific knowledge, verified by review — see
"What this package is NOT" below). A host module wraps these primitives with its own policy
(which ids are always-included, which kinds need no guard, etc.) in its own adapter layer; this
package never evaluates that policy itself.

## Adapter contract v1 (0.x — additive-only within this major)

This package is pre-1.0: exports are additive-only for the life of contract v1 (no removals, no
signature changes, no renames). A breaking change bumps to contract v2 and is called out
explicitly in this section.

### What the host MUST supply

- **`load.mjs` (`loadCatalog`/`loadAllBuilds`/`loadEdition`)** — a repo root containing
  `editions/features.json` and `editions/builds/*.json`. This directory layout is a fixed
  convention of the package, not configurable.
- **`resolve.mjs` (`resolveBuild`)** — `alwaysIncludedIds`: a **frozen `Set<string>`**, governed
  by a REQUIRED fail-closed protocol (resolveBuild performs none of this validation itself):
  1. The host computes this set from its own "these kinds always ship" policy exactly once per
     resolution flow.
  2. The host **MUST validate it against its catalog BEFORE calling `resolveBuild`**, and **MUST
     throw on any violation**. This is an *exact-set* check — nothing outside the catalog, AND
     exactly the ids the host's policy demands — not a count check; a set that's merely the right
     size but wrong membership passes a count check and must not pass this one.
  3. Semantics: every id in the set is unioned into `included` regardless of the build's own
     declared include list, and is thereby **NEVER leak-scanned** (any leak-scanning the host runs
     against the *excluded* set never sees these ids, on the assumption an always-included id
     appears in every bundle). A wrong set silently blinds the leak gate — which is exactly why
     step 2 is mandatory, not advisory.
  4. The package snapshots the Set at call time (a defensive copy taken immediately inside
     `resolveBuild`) and never mutates it. Note `Object.freeze` on a `Set` only freezes the
     *binding* — it does not deep-freeze the Set's contents, so entries can still be added or
     removed through the live reference. Any mutation of the set *after* the host's own step-2
     validation is therefore a **host bug**, not something this package can catch or protect
     against.

  (StoryFlow's `scripts/lib/adapter/universality.mjs` — `computeAlwaysIncludedIds` +
  `validateAlwaysIncluded` — is the reference implementation of steps 1–2.)
- **`scan.mjs` (`findPresentPairs`/`findAbsentPairs`) — scan coverage obligation**: both functions
  silently **skip** any feature whose `leakIdentifiers` is missing or empty — no error, no
  warning, just fewer pairs in the result. Hosts **MUST** run `findUnscannable(features)` over
  every feature they expect the leak gate to protect, and fail loudly (throw, don't just log) on
  a non-empty result — or add `leakIdentifiers` for those features. `findUnscannable` exists so
  this coverage gap is checkable instead of silent.
- **`guards.mjs` (`checkFeatureGuardsUsed`)** — `guardExemptKinds`: an iterable of catalog `kind`
  values that need no `__FEATURE_*__` guard reference (e.g. a kind whose build-time gate is a
  generated import list rather than a compile-time constant). `sourceLabel`: how the host's
  source tree names itself in problem messages (default `"the source tree"`).
- **`defines.mjs` (`editionDefines`)** — `buildFlagDefines`: a map of build-definition-level flag
  key → the define name it should emit (e.g. `{ debugMode: "__FEATURE_DEBUG_MODE__" }`). This is
  for flags that live on the build definition itself, not a `features.json` catalog entry.
  `editionDefineName` (optional, **0.2.0 behavior change, deliberate, single-consumer approved**):
  when supplied, emits `defines[editionDefineName] = JSON.stringify(buildDef.id)`. When omitted,
  **no edition-id define is emitted at all** — prior to 0.2.0 this define was always emitted as
  `__EDITION__`; as of 0.2.0 it is opt-in. The only consumer (StoryFlow) had already retired the
  constant, so this is not called out as a contract v2 break, but a host relying on the old
  always-on `__EDITION__` must now pass `editionDefineName: "__EDITION__"` explicitly to keep
  receiving it.
- **`compare-golden.mjs` (`compareGolden`)** — `fields`: an ordered
  `Array<{label: string, key: string}>` naming which top-level keys of the actual/golden objects
  to compare and what human-readable label to report each one under.

### What this package promises

- **Stable exports list** (see `package.json`'s `exports` map — one subpath per module):
  - `@dungeons-lab/editions/resolve` → `resolveBuild`
  - `@dungeons-lab/editions/scan` → `findPresent`, `findAbsent`, `findPresentPairs`,
    `findAbsentPairs`, `findUnscannable`
  - `@dungeons-lab/editions/guards` → `checkFeatureGuardsUsed`
  - `@dungeons-lab/editions/load` → `loadCatalog`, `loadAllBuilds`, `loadEdition`
  - `@dungeons-lab/editions/defines` → `editionDefines`
  - `@dungeons-lab/editions/compare-golden` → `compareGolden`
  - `@dungeons-lab/editions/constant-name` → `featureConstantName`
- **No barrel `"."` entry.** There is no top-level index — the source never had one. Import each
  module from its own subpath, as above.
- **Simple policy export:** `@dungeons-lab/editions/simple` provides the browser-clean,
  Vite-independent `free | paid | test` policy used by simple-mode modules and adapters.
- **Additive-only changes within contract v1**: new exports, new optional parameters, and bug
  fixes that don't change an existing function's observable contract are all fair game; anything
  else is a v2.

### What this package is NOT

- **Host catalog `kind` values are not package API.** `plugin`, `node`, `node-package`,
  `app-package`, `subfeature`, etc. are the host's own vocabulary for `features.json` entries.
  This package's functions take `kind` values (and `guardExemptKinds`, `alwaysIncludedIds`) as
  opaque strings/sets — it has no built-in list of kinds and enforces no policy about what any
  particular kind means.
- **No policy evaluation.** `resolveBuild` never decides which ids are "always included";
  `checkFeatureGuardsUsed` never decides which kinds are exempt; `editionDefines` never decides
  which build-def flags exist. All of that is supplied by the caller, every call.
- **No fail-closed validation of `alwaysIncludedIds` on its own.** That guard lives in the host's
  adapter layer (see above) — this package trusts the set it's given.

## Usage

```js
import { loadEdition } from "@dungeons-lab/editions/load";
import { resolveBuild } from "@dungeons-lab/editions/resolve";
import { editionDefines } from "@dungeons-lab/editions/defines";

const { catalog, buildDef, allBuilds } = loadEdition(repoRoot, "beta");
const resolved = resolveBuild(catalog, buildDef, allBuilds, {
  alwaysIncludedIds: myValidatedAlwaysIncludedSet,
});
const defines = editionDefines(
  { catalog, buildDef, resolved },
  {
    // Omit editionDefineName entirely for no edition-id define (0.2.0 default). Pass it only if
    // the host still wants one, e.g. editionDefineName: "__EDITION__".
    buildFlagDefines: { debugMode: "__FEATURE_DEBUG_MODE__" },
  },
);
```

## Testing

`npm test` runs the portable unit tests (ported verbatim from StoryFlow's
`test/editions-core/*.test.js`, import paths rewritten to this package's `src/`) plus
`test/exports.test.mjs`, which imports every subpath in the `exports` map and asserts the
expected named exports exist. `npm run pack-smoke` (`scripts/pack-smoke.mjs`) builds a tarball
via `npm pack`, installs it into a scratch temp project, and re-runs the same tests against the
installed package to prove the tarball's `exports` map actually serves every module the tests
need — not just the `src/` files on disk.

## License

`UNLICENSED` — proprietary, internal to Dungeons LAB; not for external distribution or reuse.
