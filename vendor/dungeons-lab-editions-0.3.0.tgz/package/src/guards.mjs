/**
 * @file Generic "manifest entry without a real guard" drift check - ZERO product-specific
 *       knowledge. A product's own kinds that need no `__FEATURE_X__` guard reference (e.g.
 *       kinds whose build-time gate is a generated import list, not a compile-time constant)
 *       are supplied via `guardExemptKinds`, never hardcoded here.
 */
import { featureConstantName } from "./constant-name.mjs";

/**
 * Every feature whose `kind` is not in `guardExemptKinds` must have its `__FEATURE_*__`
 * constant (its `guard` field, or the value featureConstantName(f.id) would produce)
 * referenced somewhere in `srcText`. The reverse direction - a constant used in source with NO
 * manifest entry - is a job for the caller's own lint globals list, not this function.
 * @param {string} srcText - all source files concatenated.
 * @param {Array<object>} features - the catalog's `features` array.
 * @param {Iterable<string>} guardExemptKinds - kinds that need no guard reference of their own.
 * @param {{sourceLabel?: string}} [opts] - `sourceLabel` names `srcText`'s origin in the
 *   problem message (default "the source tree"); the caller passes its own tree's conventional
 *   name (e.g. "src/") so the message reads naturally for that codebase.
 * @returns {string[]} human-readable problems; empty when compliant.
 */
export function checkFeatureGuardsUsed(
  srcText,
  features,
  guardExemptKinds,
  { sourceLabel = "the source tree" } = {},
) {
  const exempt = new Set(guardExemptKinds);
  const problems = [];
  for (const f of features) {
    if (exempt.has(f.kind)) continue;
    const constant = f.guard ?? featureConstantName(f.id);
    if (!srcText.includes(constant)) {
      problems.push(
        `feature "${f.id}": constant ${constant} is never referenced in ${sourceLabel} - ` +
          `guard the feature's code with it or remove the editions/features.json entry.`,
      );
    }
  }
  return problems;
}
