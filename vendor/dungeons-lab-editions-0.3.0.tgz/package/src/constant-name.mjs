/**
 * @file Generic compile-time constant naming - ZERO product-specific knowledge.
 */

/**
 * Compile-time constant name for a feature id: loot-crate → __FEATURE_LOOT_CRATE__.
 * Dotted node-type ids (e.g. "author.trigger.timer") are normalized the same way as dashes
 * (→ __FEATURE_AUTHOR_TRIGGER_TIMER__) - a dot left in place would produce a member-expression
 * (`__FEATURE_AUTHOR.TRIGGER.TIMER__`) that a bundler's `define` can still substitute, but that
 * ESLint's globals list (generated from this same function) can't recognize, since
 * no-undef only checks the identifier before the dot.
 * @param {string} id
 * @returns {string}
 */
export function featureConstantName(id) {
  return `__FEATURE_${id.toUpperCase().replaceAll(/[.-]/g, "_")}__`;
}
