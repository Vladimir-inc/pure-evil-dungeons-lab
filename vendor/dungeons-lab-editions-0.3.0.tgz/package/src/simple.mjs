export const SIMPLE_EDITIONS = Object.freeze(["free", "paid", "test"]);

export function assertEdition(id) {
  if (!SIMPLE_EDITIONS.includes(id)) {
    throw new Error(`Unknown Dungeons LAB edition ${JSON.stringify(id)}; expected free, paid, or test`);
  }
  return id;
}

export function devToolsEnabled(edition) {
  return assertEdition(edition) === "test";
}

export function manifestOverlay(baseManifest, edition, {
  freeManifestUrl,
  freeDownloadUrl,
} = {}) {
  assertEdition(edition);
  if (!baseManifest || typeof baseManifest !== "object" || Array.isArray(baseManifest)) {
    throw new TypeError("manifestOverlay: baseManifest must be an object");
  }

  const isFree = edition === "free";
  return {
    ...baseManifest,
    flags: { ...(baseManifest.flags ?? {}), dlEdition: edition },
    // Always overwrite both fields. In particular, paid/test must never inherit a public URL
    // already present on the base manifest or supplied for the free edition.
    manifest: isFree ? (freeManifestUrl ?? "") : "",
    download: isFree ? (freeDownloadUrl ?? "") : "",
  };
}

export function assertPackagingAllowed(edition) {
  assertEdition(edition);
  if (edition === "test") {
    throw new Error("The test edition is local-only and may never be packaged");
  }
  return edition;
}
