/**
 * @file Generic catalog/build resolution engine - ZERO product-specific knowledge (lift-ready
 *       verbatim into a future standalone package). A "catalog" is `{features: [...], groups:
 *       {...}}` of zero membership; a "build definition" positively declares what it includes
 *       (feature ids, `@group` aliases, `"*"` for everything, and optionally `extends` another
 *       build). resolveBuild() is the one function that turns a catalog + a build definition
 *       into a `{included, excluded}` split.
 *
 *       This module evaluates NO policy/predicate of its own: a caller that needs certain ids
 *       unioned into `included` regardless of the build's own declared include list (e.g. a
 *       product's "these kinds always ship" runtime-wide policy) supplies them via the
 *       `alwaysIncludedIds` option. See the adapter layer for the host application's own
 *       policy + the fail-closed validation wrapped around it (resolveValidated).
 */

/**
 * Expand one `include` list token into one-or-more real feature ids.
 * @param {string} token - a feature id, a `"*"` wildcard, or a `"@group"` alias.
 * @param {Set<string>} knownIds - every real feature id in the catalog.
 * @param {Record<string, string[]>} groups - catalog.groups.
 * @param {string} buildId - for error messages.
 * @returns {string[]}
 */
function expandIncludeToken(token, knownIds, groups, buildId) {
  if (token === "*") return [...knownIds];
  if (typeof token === "string" && token.startsWith("@")) {
    const members = groups[token];
    if (!members) {
      throw new Error(
        `Unknown group alias "${token}" in build "${buildId}"'s include list. ` +
          `Known groups: ${Object.keys(groups).join(", ") || "(none)"}`,
      );
    }
    for (const m of members) {
      if (!knownIds.has(m)) {
        throw new Error(
          `Group "${token}" (referenced by build "${buildId}") contains unknown feature id "${m}".`,
        );
      }
    }
    return members;
  }
  if (!knownIds.has(token)) {
    throw new Error(
      `Unknown feature id "${token}" in build "${buildId}"'s include list. ` +
        `Known: ${[...knownIds].join(", ")}`,
    );
  }
  return [token];
}

/**
 * Recursively resolve one build definition's own `include` list PLUS (if present) its
 * `extends` parent's resolved include set, into a flat Set of real feature ids.
 * @param {object} buildDef
 * @param {Set<string>} knownIds
 * @param {Record<string, string[]>} groups
 * @param {Record<string, object>} allBuilds
 * @param {Set<string>} chain - build ids visited so far in this `extends` chain (cycle guard).
 * @returns {Set<string>}
 */
function resolveIncludedIds(buildDef, knownIds, groups, allBuilds, chain) {
  const own = (buildDef.include ?? []).flatMap((t) =>
    expandIncludeToken(t, knownIds, groups, buildDef.id),
  );
  const ids = new Set(own);
  if (buildDef.extends) {
    if (chain.has(buildDef.extends)) {
      throw new Error(
        `Circular "extends" chain in build "${buildDef.id}" (already visited "${buildDef.extends}").`,
      );
    }
    const parent = allBuilds[buildDef.extends];
    if (!parent) {
      throw new Error(
        `Unknown extends target "${buildDef.extends}" in build "${buildDef.id}". ` +
          `Known builds: ${Object.keys(allBuilds).join(", ") || "(none)"}`,
      );
    }
    const parentIds = resolveIncludedIds(
      parent,
      knownIds,
      groups,
      allBuilds,
      new Set([...chain, buildDef.extends]),
    );
    for (const id of parentIds) ids.add(id);
  }
  return ids;
}

/**
 * Split the feature catalog into included/excluded per a build definition. Throws on an
 * unknown feature id, unknown `@group` alias, or unknown `extends` target (typo guard - the
 * include list is hand-edited).
 * @param {{features: Array<object>, groups?: Record<string, string[]>}} catalog -
 *   the feature catalog.
 * @param {{id: string, title?: string, extends?: string, include: string[]}} buildDef - one
 *   build definition.
 * @param {Record<string, object>} [allBuilds] - id → buildDef, for resolving `extends` (only
 *   needed if `buildDef.extends` is set).
 * @param {{alwaysIncludedIds?: Iterable<string>}} [opts] - ids to union into `included`
 *   regardless of this build's declared include list, e.g. a runtime-wide policy the caller
 *   has already evaluated. Core resolveBuild evaluates no such policy itself. This package never
 *   mutates the supplied Set and snapshots it (a defensive copy) at call time, so a caller that
 *   mutates its own Set after calling resolveBuild cannot change a resolution already in flight.
 * @returns {{buildId: string, included: Array<object>, excluded: Array<object>}}
 */
export function resolveBuild(catalog, buildDef, allBuilds = {}, { alwaysIncludedIds } = {}) {
  if (!buildDef?.id) throw new Error("Build definition is missing an 'id'");
  const features = catalog?.features ?? [];
  const groups = catalog?.groups ?? {};
  const knownIds = new Set(features.map((f) => f.id));
  // Defensive copy, snapshotted immediately: later external mutation of the caller's Set must
  // not change a resolution already in flight (see the opts JSDoc above).
  const always = new Set(alwaysIncludedIds ?? []);

  const includedIds = resolveIncludedIds(
    buildDef,
    knownIds,
    groups,
    allBuilds,
    new Set([buildDef.id]),
  );

  for (const id of always) includedIds.add(id);

  return {
    buildId: buildDef.id,
    included: features.filter((f) => includedIds.has(f.id)),
    excluded: features.filter((f) => !includedIds.has(f.id)),
  };
}
