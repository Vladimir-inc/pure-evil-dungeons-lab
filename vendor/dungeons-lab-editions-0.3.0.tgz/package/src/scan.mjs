/**
 * @file Generic bundle-text scanning primitives - ZERO product-specific knowledge. Two flat
 *       primitives (findPresent/findAbsent) over a plain identifier list, plus a thin
 *       "identifier-pairs" variant that preserves the `{featureId, identifier}` result shape
 *       the leak/liveness gates have always returned (one pair per feature × identifier).
 */

/**
 * @param {string} bundleText
 * @param {string[]} ids
 * @returns {string[]} the ids present in bundleText.
 */
export function findPresent(bundleText, ids) {
  return ids.filter((id) => bundleText.includes(id));
}

/**
 * @param {string} bundleText
 * @param {string[]} ids
 * @returns {string[]} the ids absent from bundleText.
 */
export function findAbsent(bundleText, ids) {
  return ids.filter((id) => !bundleText.includes(id));
}

/**
 * @param {string} bundleText
 * @param {Array<{id: string, leakIdentifiers?: string[]}>} features
 * @param {(bundleText: string, ids: string[]) => string[]} scanFn - findPresent or findAbsent.
 * @returns {Array<{featureId: string, identifier: string}>}
 */
function scanFeaturePairs(bundleText, features, scanFn) {
  const pairs = [];
  for (const f of features) {
    // Hardened: a feature without leakIdentifiers contributes nothing - never a TypeError
    // (the pre-split findLeaks dereferenced f.leakIdentifiers unguarded).
    const ids = f.leakIdentifiers ?? [];
    for (const identifier of scanFn(bundleText, ids)) {
      pairs.push({ featureId: f.id, identifier });
    }
  }
  return pairs;
}

/**
 * @param {string} bundleText
 * @param {Array<{id: string, leakIdentifiers?: string[]}>} features
 * @returns {Array<{featureId: string, identifier: string}>} one pair per present identifier.
 */
export function findPresentPairs(bundleText, features) {
  return scanFeaturePairs(bundleText, features, findPresent);
}

/**
 * @param {string} bundleText
 * @param {Array<{id: string, leakIdentifiers?: string[]}>} features
 * @returns {Array<{featureId: string, identifier: string}>} one pair per absent identifier.
 */
export function findAbsentPairs(bundleText, features) {
  return scanFeaturePairs(bundleText, features, findAbsent);
}

/**
 * Checkable coverage invariant for the pair scans: findPresentPairs/findAbsentPairs silently
 * skip any feature whose `leakIdentifiers` is missing or empty (see scanFeaturePairs above) - no
 * error, no warning, just fewer pairs. A host that relies on leak-scanning to protect an
 * excluded feature MUST enforce coverage over the features it cares about; this function is what
 * makes that coverage checkable.
 * @param {Array<{id: string, leakIdentifiers?: string[]}>} features
 * @returns {string[]} ids of features whose leakIdentifiers is missing or empty.
 */
export function findUnscannable(features) {
  return features.filter((f) => !f.leakIdentifiers?.length).map((f) => f.id);
}
