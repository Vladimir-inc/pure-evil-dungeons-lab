/**
 * @file Generic golden-snapshot comparator - ZERO product-specific knowledge. Compares an
 *       arbitrary ordered list of `{label, key}` fields between an "actual" object and a
 *       committed "golden" one via JSON.stringify equality, producing the same
 *       `"<label> changed:\n    golden: <json>\n    actual: <json>"` string shape the original
 *       (host-specific, fixed-field) frozen-contract check always produced.
 */

/**
 * @param {object} actual
 * @param {object} golden
 * @param {Array<{label: string, key: string}>} fields - which top-level keys to compare, in
 *   order, and the human-readable label to report each one under.
 * @returns {string[]} human-readable diffs; empty when identical.
 */
export function compareGolden(actual, golden, fields) {
  const problems = [];
  for (const { label, key } of fields) {
    const aJson = JSON.stringify(actual?.[key]);
    const gJson = JSON.stringify(golden?.[key]);
    if (aJson !== gJson) {
      problems.push(`${label} changed:\n    golden: ${gJson}\n    actual: ${aJson}`);
    }
  }
  return problems;
}
