/**
 * @file Generic catalog/build-definition loading - ZERO product-specific knowledge, except the
 *       fixed `editions/features.json` + `editions/builds/*.json` layout convention itself
 *       (lift-ready as-is: any product using this engine keeps this same directory shape).
 *       Moved here from the host's build-config loader (Phase 1, Task 3 of the Ecosystem Forge
 *       refactor) - that file re-exports these for compatibility.
 */
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { resolveBuild } from "./resolve.mjs";

/**
 * Read ONLY the feature catalog (`<root>/editions/features.json`) - never touches
 * `editions/builds/`. For callers that just need the catalog (e.g. eslint.config.mjs deriving
 * its guard-global list).
 * @param {string} root - repo root.
 * @returns {{features: Array<object>, groups: Record<string,string[]>}}
 */
export function loadCatalog(root) {
  return JSON.parse(readFileSync(join(root, "editions/features.json"), "utf8"));
}

/**
 * Read the catalog and every build definition from `<root>/editions/`, without picking one -
 * for callers that iterate ALL builds rather than resolving a single build id (editions:check,
 * editions:matrix).
 * @param {string} root - repo root.
 * @returns {{catalog: {features: Array<object>, groups: Record<string,string[]>}, allBuilds: Record<string, object>}}
 */
export function loadAllBuilds(root) {
  const catalog = loadCatalog(root);
  const buildsDir = join(root, "editions", "builds");
  const allBuilds = {};
  for (const entry of readdirSync(buildsDir)) {
    if (!entry.endsWith(".json")) continue;
    const def = JSON.parse(readFileSync(join(buildsDir, entry), "utf8"));
    allBuilds[def.id] = def;
  }
  return { catalog, allBuilds };
}

/**
 * Read the catalog and every build definition from `<root>/editions/`, then resolve ONE build
 * by id. The fail-fast resolveBuild() call here only proves the build's include list has no
 * typo (unknown feature id / `@group` alias / `extends` target) - it never evaluates any
 * always-included policy (this module is core, policy-free), so its result is discarded.
 * @param {string} root - repo root.
 * @param {string} buildId - e.g. "full" | "beta".
 * @returns {{catalog: {features: Array<object>, groups: Record<string,string[]>}, buildDef: object, allBuilds: Record<string, object>}}
 */
export function loadEdition(root, buildId) {
  const { catalog, allBuilds } = loadAllBuilds(root);
  const buildDef = allBuilds[buildId];
  if (!buildDef) {
    throw new Error(
      `Unknown build id "${buildId}" - no editions/builds/${buildId}.json found. ` +
        `Known builds: ${Object.keys(allBuilds).join(", ") || "(none)"}`,
    );
  }
  resolveBuild(catalog, buildDef, allBuilds); // fail fast on typos at config time
  return { catalog, buildDef, allBuilds };
}
