/**
 * @file Generic compile-time `define` map - ZERO product-specific knowledge. Emits one boolean
 *       per catalog feature that carries a `guard` field (true iff included in the already-
 *       resolved build), plus one boolean per caller-supplied build-DEFINITION-level flag (a
 *       flag that lives on the build definition itself, not a features.json catalog entry -
 *       e.g. the host application's own debug-tooling flag), mapped to whatever define name the
 *       caller wants. The edition-id define itself is opt-in (see `editionDefineName` below) -
 *       this module never assumes the host wants one.
 */

/**
 * @param {{catalog: {features: Array<object>}, buildDef: {id: string}, resolved: {included: Array<object>}}} ctx
 *   - `resolved` is the caller's already-computed resolveBuild() result (this module never
 *   resolves a build itself - policy/validation is entirely the caller's job).
 * @param {{editionDefineName?: string, buildFlagDefines?: Record<string, string>}} [opts]
 *   - `editionDefineName`: when supplied, emits `defines[editionDefineName] =
 *   JSON.stringify(buildDef.id)`. When omitted, no edition-id define is emitted at all (0.2.0
 *   contract: opt-in, not automatic).
 *   - `buildFlagDefines`: buildDef flag key → define name, e.g.
 *   `{ debugMode: "__FEATURE_DEBUG_MODE__" }`. Each emits `JSON.stringify(!!buildDef[flagKey])`.
 * @returns {Record<string, string>}
 */
export function editionDefines(
  { catalog, buildDef, resolved },
  { editionDefineName, buildFlagDefines = {} } = {},
) {
  const includedIds = new Set(resolved.included.map((f) => f.id));
  const defines = {};
  if (editionDefineName) {
    defines[editionDefineName] = JSON.stringify(buildDef.id);
  }
  for (const f of catalog.features) {
    // Guard-less features (kinds with no compile-time toggle) have no compile-time constant.
    if (!f.guard) continue;
    defines[f.guard] = JSON.stringify(includedIds.has(f.id));
  }
  for (const [flagKey, defineName] of Object.entries(buildFlagDefines)) {
    defines[defineName] = JSON.stringify(!!buildDef[flagKey]);
  }
  return defines;
}
